"use client"

import { useState, useRef, useEffect } from "react"
import { Mic, MicOff, Send, Sparkles, Volume2, Play, Pause, Square, Keyboard } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function VoxCoach() {
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [feedback, setFeedback] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isPlayingQuestion, setIsPlayingQuestion] = useState(false)
  const [showTextInput, setShowTextInput] = useState(false)
  const [textAnswer, setTextAnswer] = useState("")
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  const interviewQuestion = "Tell me about a time when you had to overcome a significant challenge at work. How did you approach it, and what was the outcome?"

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
      if (audioUrl) URL.revokeObjectURL(audioUrl)
    }
  }, [audioUrl])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      chunksRef.current = []

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data)
        }
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' })
        setAudioBlob(blob)
        const url = URL.createObjectURL(blob)
        setAudioUrl(url)
        stream.getTracks().forEach(track => track.stop())
      }

      mediaRecorder.start()
      setIsRecording(true)
      setRecordingTime(0)
      
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1)
      }, 1000)
    } catch (err) {
      console.error('Error accessing microphone:', err)
      alert('Please allow microphone access to record your answer.')
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
      if (timerRef.current) {
        clearInterval(timerRef.current)
        timerRef.current = null
      }
    }
  }

  const discardRecording = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl)
    setAudioBlob(null)
    setAudioUrl(null)
    setRecordingTime(0)
  }

  const playQuestion = () => {
    const utterance = new SpeechSynthesisUtterance(interviewQuestion)
    utterance.rate = 0.9
    utterance.pitch = 1
    utterance.onstart = () => setIsPlayingQuestion(true)
    utterance.onend = () => setIsPlayingQuestion(false)
    speechSynthesis.speak(utterance)
  }

  const stopQuestion = () => {
    speechSynthesis.cancel()
    setIsPlayingQuestion(false)
  }

  const handleSubmit = async () => {
    if (!audioBlob && !textAnswer.trim()) return
    
    setIsSubmitting(true)
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    setFeedback(`Great response! Here's my analysis:

**Strengths:**
• You provided a clear example with context
• Good use of the STAR method structure
• Demonstrated problem-solving skills

**Areas for Improvement:**
• Consider adding more specific metrics or outcomes
• Try to connect the experience to the role you're applying for
• Practice delivering this in under 2 minutes

**Overall Score:** 7.5/10 - Strong foundation with room for polish!`)
    
    setIsSubmitting(false)
  }

  const hasAnswer = audioBlob || textAnswer.trim()

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 relative overflow-hidden">
      {/* Background gradient orbs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal-500/10 rounded-full blur-3xl" />
      
      <div className="relative z-10 container mx-auto px-4 py-12 max-w-3xl">
        {/* Header */}
        <header className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-cyan-500 to-indigo-600 shadow-lg shadow-cyan-500/25">
              <Mic className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-teal-300 to-indigo-400 bg-clip-text text-transparent">
              VoxCoach
            </h1>
          </div>
          <p className="text-slate-400 text-lg">
            Master your interview skills with AI-powered voice coaching
          </p>
        </header>

        {/* Interview Question Card */}
        <section className="mb-8">
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <span className="text-sm font-medium text-cyan-400 uppercase tracking-wider">
                  Interview Question
                </span>
              </div>
              <Button
                onClick={isPlayingQuestion ? stopQuestion : playQuestion}
                variant="ghost"
                className="flex items-center gap-2 text-teal-400 hover:text-teal-300 hover:bg-teal-500/10"
              >
                {isPlayingQuestion ? (
                  <>
                    <Pause className="w-4 h-4" />
                    Stop
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" />
                    Listen
                  </>
                )}
              </Button>
            </div>
            <p className="text-xl text-slate-100 leading-relaxed font-medium">
              {interviewQuestion}
            </p>
          </div>
        </section>

        {/* Voice Recording Section */}
        <section className="mb-8">
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <span className="text-sm font-medium text-slate-300">
                Your Answer
              </span>
              <Button
                onClick={() => setShowTextInput(!showTextInput)}
                variant="ghost"
                size="sm"
                className="text-slate-400 hover:text-slate-300 hover:bg-white/5"
              >
                <Keyboard className="w-4 h-4 mr-2" />
                {showTextInput ? 'Use Voice' : 'Use Text'}
              </Button>
            </div>

            {!showTextInput ? (
              /* Voice Recording Interface */
              <div className="flex flex-col items-center">
                {!audioUrl ? (
                  <>
                    {/* Recording Button */}
                    <button
                      onClick={isRecording ? stopRecording : startRecording}
                      className={`relative w-32 h-32 rounded-full transition-all duration-300 ${
                        isRecording 
                          ? 'bg-gradient-to-br from-red-500 to-rose-600 shadow-lg shadow-red-500/40 scale-110' 
                          : 'bg-gradient-to-br from-cyan-500 to-indigo-600 shadow-lg shadow-cyan-500/25 hover:scale-105 hover:shadow-cyan-500/40'
                      }`}
                    >
                      {isRecording && (
                        <span className="absolute inset-0 rounded-full bg-red-500/50 animate-ping" />
                      )}
                      <span className="relative flex items-center justify-center">
                        {isRecording ? (
                          <MicOff className="w-12 h-12 text-white" />
                        ) : (
                          <Mic className="w-12 h-12 text-white" />
                        )}
                      </span>
                    </button>

                    {/* Recording Status */}
                    <div className="mt-6 text-center">
                      {isRecording ? (
                        <>
                          <div className="flex items-center gap-2 justify-center mb-2">
                            <span className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                            <span className="text-red-400 font-medium">Recording...</span>
                          </div>
                          <span className="text-2xl font-mono text-slate-200">
                            {formatTime(recordingTime)}
                          </span>
                        </>
                      ) : (
                        <p className="text-slate-400">
                          Tap to start recording your answer
                        </p>
                      )}
                    </div>
                  </>
                ) : (
                  /* Recorded Audio Preview */
                  <div className="w-full">
                    <div className="bg-slate-900/50 rounded-2xl p-6 mb-4">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 rounded-xl bg-gradient-to-br from-cyan-500 to-indigo-600">
                          <Mic className="w-4 h-4 text-white" />
                        </div>
                        <span className="text-slate-300 font-medium">Your Recording</span>
                        <span className="ml-auto text-sm text-slate-500">{formatTime(recordingTime)}</span>
                      </div>
                      <audio
                        src={audioUrl}
                        controls
                        className="w-full h-12 [&::-webkit-media-controls-panel]:bg-slate-800"
                      />
                    </div>
                    <div className="flex gap-3 justify-center">
                      <Button
                        onClick={discardRecording}
                        variant="outline"
                        className="border-slate-600 text-slate-300 hover:bg-slate-800"
                      >
                        <Square className="w-4 h-4 mr-2" />
                        Discard
                      </Button>
                      <Button
                        onClick={startRecording}
                        variant="outline"
                        className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
                      >
                        <Mic className="w-4 h-4 mr-2" />
                        Re-record
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* Text Input Fallback */
              <div>
                <textarea
                  value={textAnswer}
                  onChange={(e) => setTextAnswer(e.target.value)}
                  placeholder="Type your response here... Be specific and use the STAR method (Situation, Task, Action, Result)"
                  className="w-full h-48 bg-slate-900/50 border border-white/10 rounded-2xl p-5 text-slate-100 placeholder-slate-500 resize-none focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50 transition-all"
                />
                <div className="mt-2 text-right">
                  <span className="text-sm text-slate-500">
                    {textAnswer.length} characters
                  </span>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="mt-8 flex justify-center">
              <Button
                onClick={handleSubmit}
                disabled={!hasAnswer || isSubmitting}
                className="bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold px-10 py-6 rounded-xl shadow-lg shadow-cyan-500/25 transition-all hover:shadow-cyan-500/40 hover:scale-105 disabled:opacity-50 disabled:hover:scale-100"
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Analyzing...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Send className="w-4 h-4" />
                    Get Feedback
                  </span>
                )}
              </Button>
            </div>
          </div>
        </section>

        {/* Feedback Section */}
        {feedback && (
          <section className="mb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="backdrop-blur-xl bg-gradient-to-br from-cyan-500/10 to-indigo-500/10 border border-cyan-500/20 rounded-3xl p-8 shadow-2xl">
              <div className="flex items-center gap-2 mb-6">
                <div className="p-2 rounded-xl bg-gradient-to-br from-cyan-500 to-indigo-600">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <span className="text-lg font-semibold text-cyan-400">
                  AI Feedback
                </span>
              </div>
              <div className="prose prose-invert prose-sm max-w-none">
                {feedback.split('\n').map((line, i) => (
                  <p key={i} className="text-slate-300 leading-relaxed mb-2">
                    {line.startsWith('**') ? (
                      <span className="font-semibold text-slate-100">
                        {line.replace(/\*\*/g, '')}
                      </span>
                    ) : line.startsWith('•') ? (
                      <span className="ml-4 block text-slate-400">{line}</span>
                    ) : (
                      line
                    )}
                  </p>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Audio Player Section */}
        {feedback && (
          <section className="animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
            <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-6 shadow-2xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600">
                  <Volume2 className="w-4 h-4 text-white" />
                </div>
                <span className="text-sm font-medium text-slate-300">
                  Voice Feedback
                </span>
              </div>
              <div className="bg-slate-900/50 rounded-2xl p-4">
                <audio
                  controls
                  className="w-full h-12 [&::-webkit-media-controls-panel]:bg-slate-800 [&::-webkit-media-controls-current-time-display]:text-slate-300 [&::-webkit-media-controls-time-remaining-display]:text-slate-300"
                >
                  <source src="/audio-feedback.mp3" type="audio/mpeg" />
                  Your browser does not support the audio element.
                </audio>
                <p className="text-xs text-slate-500 mt-3 text-center">
                  Listen to your personalized AI coaching feedback
                </p>
              </div>
            </div>
          </section>
        )}

        {/* Footer */}
        <footer className="text-center mt-12 text-slate-500 text-sm">
          <p>Powered by AI to help you ace your next interview</p>
        </footer>
      </div>
    </main>
  )
}
